C2C Endpoints
=============

Get C2C Trade History (USER_DATA)
---------------------------------
.. autofunction:: binance.spot.c2c.c2c_trade_history
