.. binance-connector documentation master file, created by
   sphinx-quickstart on Thu Jun  3 10:37:38 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: intro.rst

Contents
=========
.. toctree::
   :maxdepth: 3

   CHANGELOG
   getting_started
   binance.spot
   binance.websocket.spot

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
