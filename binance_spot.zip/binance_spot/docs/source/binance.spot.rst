Spot APIs
=========

.. toctree::
   :maxdepth: 2

   binance.spot.blvt
   binance.spot.bswap
   binance.spot.c2c
   binance.spot.convert
   binance.spot.data_stream
   binance.spot.fiat
   binance.spot.futures
   binance.spot.gift_card
   binance.spot.loan
   binance.spot.margin
   binance.spot.market
   binance.spot.mining
   binance.spot.nft
   binance.spot.pay
   binance.spot.portfolio_margin
   binance.spot.rebate
   binance.spot.savings
   binance.spot.staking
   binance.spot.sub_account
   binance.spot.trade
   binance.spot.wallet
