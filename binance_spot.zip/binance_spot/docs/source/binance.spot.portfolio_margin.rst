Portfolio Margin Endpoints
==========================


Get Portfolio Margin Account Info (USER_DATA)
---------------------------------------------
.. autofunction:: binance.spot.portfolio_margin.portfolio_margin_account

Query Portfolio Margin Bankruptcy Loan Amount (USER_DATA)
---------------------------------------------------------
.. autofunction:: binance.spot.portfolio_margin.portfolio_margin_bankruptcy_loan_amount

Portfolio Margin Bankruptcy Loan Repay (USER_DATA)
--------------------------------------------------
.. autofunction:: binance.spot.portfolio_margin.portfolio_margin_bankruptcy_loan_repay