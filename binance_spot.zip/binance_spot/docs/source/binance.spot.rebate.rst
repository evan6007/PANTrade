Rebate Endpoints
================

Get Spot Rebate History Records (USER_DATA)
-------------------------------------------
.. autofunction:: binance.spot.rebate.rebate_spot_history
