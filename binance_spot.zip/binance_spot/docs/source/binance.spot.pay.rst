Pay Endpoints
=============

Get Pay Trade History (USER_DATA)
---------------------------------
.. autofunction:: binance.spot.pay.pay_history
