NFT Endpoints
=============

Get NFT Transaction History (USER_DATA)
---------------------------------------
.. autofunction:: binance.spot.nft.nft_transaction_history

Get NFT Deposit History(USER_DATA)
----------------------------------
.. autofunction:: binance.spot.nft.nft_deposit_history

Get NFT Withdraw History (USER_DATA)
------------------------------------
.. autofunction:: binance.spot.nft.nft_withdraw_history

Get NFT Asset (USER_DATA)
-------------------------
.. autofunction:: binance.spot.nft.nft_asset