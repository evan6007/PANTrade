Fiat Endpoints
==============

Get Fiat Order History (USER_DATA)
---------------------------------------------
.. autofunction:: binance.spot.fiat.fiat_order_history

Get Fiat Payments History (USER_DATA)
---------------------------------------------
.. autofunction:: binance.spot.fiat.fiat_payment_history
