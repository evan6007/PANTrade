Convert Endpoints
=================


Get Convert Trade History (USER_DATA)
-------------------------------------
.. autofunction:: binance.spot.convert.convert_trade_history
