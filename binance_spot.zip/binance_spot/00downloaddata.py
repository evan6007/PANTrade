from binance.spot import Spot 
import pandas as pd
import datetime


client = Spot()

# Get server timestamp
print(client.time())

start = str(int(datetime.datetime(2023,1,3).timestamp()*1000))
end = str(int(datetime.datetime(2023,1,15).timestamp()*1000))

print(start)
print(end)
print(int(end)-int(start))
print((int(end)-int(start))/(15*60*1000))
print((int(end)-int(start))/(15*60*1000)/1000)

batchs=int((int(end)-int(start))/(15*60*1000)/1000)+1
print(batchs)

m15=15*60*1000 #15分鐘轉換成毫秒

for i in range(batchs+1):
    print("batch=",i)
    if i == 0:
        new_start=int(start)+m15*i*1000
        new_end=int(start)+m15*(i+1)*1000
        df=pd.DataFrame(client.klines("BTCUSDT", "15m",limit=1000,startTime=str(new_start),endTime=str(new_end)))

    if i < batchs and i > 0:
        new_start=int(start)+m15*i*1000
        new_end=int(start)+m15*(i+1)*1000
        df=pd.concat([df,pd.DataFrame(client.klines("BTCUSDT", "15m",limit=1000,startTime=str(new_start),endTime=str(new_end)))],axis=0)
    if i == batchs:
        new_start=int(start)+m15*i*1000
        new_end=end
        df=pd.concat([df,pd.DataFrame(client.klines("BTCUSDT", "15m",limit=1000,startTime=str(new_start),endTime=str(new_end)))],axis=0)

print(len(df))
df.columns = ['datetime', 'open', 'high', 'low', 'close', 'volume','close_time', 'qav', 'num_trades','taker_base_vol', 'taker_quote_vol', 'ignore']

df=df[['datetime', 'open', 'high', 'low', 'close']]
df.index = [datetime.datetime.fromtimestamp(x/1000.0) for x in df.datetime]
df.to_csv("BTCUSTD15m_2023.csv")



#df=df.drop_duplicates()
#df.columns = ['datetime', 'open', 'high', 'low', 'close', 'volume','close_time', 'qav', 'num_trades','taker_base_vol', 'taker_quote_vol', 'ignore']
#df.index = [datetime.datetime.fromtimestamp(x/1000.0) for x in df.datetime]
#df.to_csv("BTCUSTD15m.csv")



#df=pd.DataFrame(client.klines("BTCUSDT", "1m",limit=1000,startTime=start,endTime=str(int(start)+60*60*12*1000)))
#for i in range(100):
#    df=pd.concat([df,pd.DataFrame(client.klines("BTCUSDT", "1m",limit=1000,startTime=str(int(start)+60*60*12*1000*(i+1))\
#    ,endTime=str(int(start)+60*60*12*1000*(i+2))))],axis=0)